# Cambios C3SAR EXTERNAL

- Identidad visible actualizada a C3SAR EXTERNAL en inicio de sesión, menú y nombre de la app.
- Imagen proporcionada aplicada al fondo de la pantalla de key y al fondo del menú (recurso ExternalPortraitBackground).
- Imagen del encabezado convertida en acceso al canal de WhatsApp y rotulada CANAL OFC.
- Texto CANAL OFC de la pantalla de key enlaza al mismo canal.

Canal: https://whatsapp.com/channel/0029VbCTB3t9MF98tEHP5a2Y
