# Cambios EL_07

- Sustituido el fondo de inicio de sesión, el fondo del panel y el fondo de Ajustes por la imagen proporcionada.
- Ajustado el recorte de imagen a `scaledToFill` para ocupar el área sin franjas negras superiores o inferiores; el icono cuadrado del panel también llena su marco.
- Renombrada la identidad visible `EXTERNAL V1` a `EL_07`, incluido el nombre mostrado de la app.
- En el inicio de sesión, el texto de acceso ahora muestra `EL_07 XITTER!!`.
- Añadida la pestaña `HOLO PJ` y el botón funcional `HOLO PJ AMARILLO`, que carga el paquete `AMARRILLO.3105` recibido y permite aplicar/restaurar el parche usando el flujo existente.
- Registrado el nuevo paquete como recurso del proyecto Xcode.
